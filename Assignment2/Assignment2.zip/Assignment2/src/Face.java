// Parent interface with the attributes Eyes, Nose, and Mouth
public interface Face {

    public abstract void eyes(); // Interface method (no body)

    public abstract void mouth(); // Interface method (no body)

    public abstract void nose(); // Interface method (no body)
}
