// Implements the face interface
// Pika Pika
public class Surprised implements Face{
    int level;

    public void eyebrow(){
        System.out.println("-ssss/--::--.-/::.----------------------.:oooooooooooooooo+`");
        System.out.println("/dhs/::////::o+++/-:////////////////////::yyhhyyysssooooosy.");
        System.out.println("./////////-:+++++//-:///////////////////:-/yssososssssooooo`");
        System.out.println(".//////-.../+++////--////////////////////:-ssoooooooosssso+`");
        System.out.println(".//////:.``.:///:::-.:////////////////////-/o++ooooooooooo+`");
        System.out.println(".//////:-.`-hyo/----.:////////////////////::o++++++++oooo++`");


    }
    @Override
    public void eyes() {
        System.out.println(".//////-/+-.ydddhs/:.-////////////////////:-oo++oooooo+++++`");
        System.out.println(".//////-/+-.ydddhs/:.-////////////////////:-oo++oooooo+++++`");
        System.out.println(".////:-/++++/+hdddddddho/://///////////////:-/++syhdddddddh.");
        System.out.println(".///:.-::--:/:/ydddddddddy+///////////////++oyhddddddddddds`");
        System.out.println(".///-.----------+hddddddddddhhhhhddddddddddddddddddddddhys+`");
    }


    @Override
    public void nose() {
        System.out.println(".//:.------------:ohhhdddddddddddddddddddddddddddddddhs/:::`");
        System.out.println(".//-.---------..----ohdddddddddddddddddddddddddddhhy+:::---`");
        System.out.println("./:......----..``.-:yddddddddddddddddddddddddddddh+::::----`");
        System.out.println(".:..---..----.``.-.odddhyo+ydddddddddddhyy/+hdddddh/-::::::`");
        System.out.println(".-`--.......----:-:hddds/:.+hddddddddddh+/..sddddddy-//////`");
        System.out.println(".`...```````---::-odddddysoyddhyyhddddddhysshddddddd+/+////`");
    }

    @Override
    public void mouth() {
        System.out.println("`.--.``````.-:::-./osyddddddddhsoshdddddddddhyyyyhdds/++++/`");
        System.out.println("`------:::::::::.-++++hdddddddddhhhddddddddhs++++ohdh//++//`");
        System.out.println("`----------::::-.:/++ohddddddh+/+oooshdddddho+++++hddy:////`");
        System.out.println(".:-------------.-yssyhdddddddh/oyyyyohddddddhssssydddd+////`");
        System.out.println("-:---------------oddddddddddddyoossoohddddddddddddddddy:+//`");
        System.out.println(".--://///++++////:odddddddddddddhhhhhdddddddddddddddddh/:::`");
        System.out.println(".------:://////:::/ydddddddddddddddddddddddddddddddddddo:::`");
        System.out.println("`---------:///////:oyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyys---`");
    }

    public void color(){
        System.out.println("The face color is Yellow.");
    }

}
