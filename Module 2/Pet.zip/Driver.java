public class Driver {
    public static void main(String[] args){
        Cat Anna = new Cat("Anna",5, "Justin");
        Dog Toby = new Dog("Toby", 10, "Justin");

        System.out.println(Anna);
        System.out.println(Toby);
    }

}
