public class Driver {
        public static void main(String[] args){
            Cat Anna = new Cat("Anna",5, "Justin");
            Dog Toby = new Dog("Toby", 10, "Justin");
            Snake Bob = new Snake("Bob", 3, "Justin");
            Panda Cupcake = new Panda ("Cupcake", 10, "Justin");

            System.out.println(Anna + " and my owner is "+ Anna.owner);
            System.out.println(Toby + " "+Toby.speak());
            System.out.println(Bob + " " + Bob.speak());
            System.out.println(Cupcake + " and I am "+Cupcake.age +" years old");
        }
}
