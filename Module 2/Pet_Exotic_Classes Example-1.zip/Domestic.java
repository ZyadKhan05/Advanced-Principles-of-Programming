public class Domestic extends Pet{
    protected int cutenessFactor;

    public Domestic(String n, int a, String o, String t){
        super(n, a, o, t);
        if (t.equals("cat")){
            cutenessFactor = 7;
        }
        else if (t.equals("dog")){
            cutenessFactor = 8;
        }
        else{
            cutenessFactor = 6;
        }
    }
    public int getCutenessFactor(){
        return cutenessFactor;
    }
    public void setCutenessFactor(int cute){
        cutenessFactor = cute;
    }
    public String toString(){
        return "I am "+ super.toString() + " and I have a cuteness factor of "+ cutenessFactor;
    }
}
