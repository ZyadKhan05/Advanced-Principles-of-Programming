public class Main {
    public static void main(String [] args)
    {
       //Creating object of derived class
       // inside main() method
       Derived derivedTest = new Derived();
       derivedTest.fun();
    }
}
