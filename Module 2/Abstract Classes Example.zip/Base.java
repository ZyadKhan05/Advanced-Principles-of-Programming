// This java Program demostrates abstract classes
abstract class Base {

    //Construtor of class 1
    Base(){
        System.out.println("Base Constructor Called");
    }
    // Abstract method inside class
    abstract void fun();
}
