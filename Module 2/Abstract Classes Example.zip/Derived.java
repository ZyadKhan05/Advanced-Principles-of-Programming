public class Derived extends Base {
    //Constructor of class 2
    Derived(){
        System.out.println("Derived Constructor Called");
    }
    void fun(){
        System.out.println("Derived fun() called");
    }
}
