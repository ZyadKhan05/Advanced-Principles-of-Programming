//Interface
public interface Animal {
    public void animalSound(); // interface method (No Body)
    public void sleep(); // interface method (no body)

    public void  color();
}
