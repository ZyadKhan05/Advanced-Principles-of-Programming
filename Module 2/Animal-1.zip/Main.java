public class Main {
    public static void main(String[] args)
    {
        hedgehog myHedgehog = new hedgehog(); // Creates a hedgehog object
        myHedgehog.animalSound();
        myHedgehog.sleep();
        myHedgehog.color();
    }
}
