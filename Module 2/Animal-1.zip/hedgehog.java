//hedgehog implements the Animal Interface
public class hedgehog implements Animal {
    @Override
    public void animalSound() {
        // The body of animalSound() is provided here
        System.out.println("Grunt Grunt");
    }

    @Override
    public void sleep() {
        System.out.println("Zzz");
    }

    @Override
    public void color() {
        System.out.println("Brown");
    }
}
