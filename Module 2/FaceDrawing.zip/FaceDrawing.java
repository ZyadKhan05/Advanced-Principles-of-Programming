public class FaceDrawing {
    public static void main(String[] args){
        System.out.println("    '.     .'");
        System.out.print(" ( | )");
        System.out.print("' . '");
        System.out.println(" ( | )");
        System.out.println(" \n        |");
        System.out.println("         )");
        System.out.print("\n");
        System.out.println("   *-----------*");

    }
}
