public class Face3 {
    public static void main(String[] args) {
        //Eyebrows Section
        System.out.println(".             .");
        System.out.println("  .         .");
        System.out.println("    .    .");

        //Eyes Section
        System.out.println("  .          .");
        System.out.println(". 0 .      . 0 .");
        System.out.println("  .          .");

        //Nose Section
        System.out.println("       .");
        System.out.println("        .");
        System.out.println("          .");
        System.out.println("        o  o");

        //Mouth Section
        System.out.println("        ..");
        System.out.println("      .     .");
        System.out.println("    .         .");
        System.out.println("  .              .");






    }
}
