public class Face2 {
    public static void main(String[] args) {
        System.out.println("  /  \\");

        System.out.println(" 0   0");

        System.out.println("   }");

        System.out.println("*-__-*");
    }
}
