import java.io.*;

// This program
 public class WriteRandomAccessFile {
     static void Write(String fileName, String fileContents) throws IOException {

         try {
             File Fo = new File(fileName+".dat");
             if (Fo.createNewFile()) {
                 System.out.println("File created: " + Fo.getName());
             }
             else {
                 System.out.println(Fo.getName() + " already exists, you cannot do that. Please try again.");
                 return;
             }
         }
         catch (IOException e) {
             System.out.println("An error has occurred");
             e.printStackTrace();
         }

         System.out.println("Opening the file...");

         RandomAccessFile randomFile = new RandomAccessFile(fileName + ".dat", "rw");

         System.out.println("Writing data to the file...");

         char[] content = fileContents.toCharArray();
         for (int i = 0; i < content.length; i++) {
             randomFile.writeChar(content[i]);
         }

         randomFile.close();
         System.out.println("Done!");
     }
  }

